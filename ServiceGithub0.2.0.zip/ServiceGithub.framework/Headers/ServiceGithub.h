//
//  ServiceGithub.h
//  ServiceGithub
//
//  Created by Zhassulan Aimukhambetov on 10/25/19.
//  Copyright © 2019 Zhassulan Aimukhambetov. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ServiceGithub.
FOUNDATION_EXPORT double ServiceGithubVersionNumber;

//! Project version string for ServiceGithub.
FOUNDATION_EXPORT const unsigned char ServiceGithubVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ServiceGithub/PublicHeader.h>


